﻿using ConsoleApp1.Functions;
using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Очікуємо рішення
            var deterministicDecision = DeterministicDecisionFunction.MakeDecision();
            // Очислюжмо втрати
            var deterministicLosses = DeterministicDecisionFunction.GetLossFunctionResult(deterministicDecision);
            // Виводимо результат
            Console.WriteLine("Deterministic Losses Function: {0}", deterministicLosses);
            
            // Очікуємо рішення
            var stochasticDecision = StochasticDecisionFunction.MakeDecision();
            // Очислюжмо втрати
            var stochasticLosses = StochasticDecisionFunction.GetLossFunctionResult(stochasticDecision);
            // Виводимо результат
            Console.WriteLine("Stochastic Losses Function: {0}", stochasticLosses);

            // Для того, щоб вікну не закривалось миттєво після завершення обрахунків
            Console.ReadLine();
        }
    }
}
