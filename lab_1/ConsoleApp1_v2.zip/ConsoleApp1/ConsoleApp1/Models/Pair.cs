﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Models
{
    // Клас для більш зручного представлення пар
    public class Pair
    {
        public int KeyId { get; set; }
        public int MessageId { get; set; }
    }
}
