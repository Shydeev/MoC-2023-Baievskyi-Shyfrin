﻿using ConsoleApp1.Data;
using ConsoleApp1.Models;
using System;

namespace ConsoleApp1.Functions
{
    public static class StochasticDecisionFunction
    {
        // Метод, який видає результат роботи стохастичної вирішуючої функції
        public static double[,] MakeDecision()
        {
            var result = new double[20, 20];

            var conditional_prob = Variant.GetConditionalProbabilities();

            for (int column = 0; column < 20; column++)
            {
                var max_value_in_column = 0d;
                var max_entrance = 0d;

                for (int row = 0; row < 20; row++)
                {
                    if (max_value_in_column < conditional_prob[row, column])
                    {
                        max_value_in_column = conditional_prob[row, column];
                    }
                }

                for (int row = 0; row < 20; row++)
                {
                    if (max_value_in_column == conditional_prob[row, column])
                    {
                        max_entrance++;
                    }
                }

                for (int row = 0; row < 20; row++)
                {
                    result[column, row] = conditional_prob[row, column] == max_value_in_column
                                            ? 1d / max_entrance
                                            : 0d;
                }
            }
            Console.WriteLine(new Matrix(result));
            return result;
        }

        // Метод, який обраховує втрати стохастичної вирішуючої функції
        public static double GetLossFunctionResult(double[,] decision)
        {
            var result = 0d;

            var P_M_C = Variant.GetCiphertextMessagesProbabilities();

            for (int messageId = 0; messageId < 20; messageId++)
            {
                for (int cipherId = 0; cipherId < 20; cipherId++)
                {
                    result += P_M_C[messageId, cipherId] * GetLossFunctionHelperResult(messageId, cipherId, decision);
                }
            }

            return result;
        }

        // Допоміжний метод
        public static double GetLossFunctionHelperResult(int _messageId, int _cipherId, double[,] decision)
        {
            var result = 0d;

            for (int messageId = 0; messageId < 20; messageId++)
            {
                if (messageId != _messageId)
                {
                    result += decision[_cipherId, messageId];
                }
            }

            return result;
        }
    }
}
